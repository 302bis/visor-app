          <!-- top tiles -->
          <div class="row tile_count">
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Mis ventas</span>
              <div class="count">54,823,426</div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>8% </i> Incremento desde el mes pasado</span>
            </div>
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-clock-o"></i> Mis finanzas</span>
              <div class="count">XX,XX</div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>-0.2 </i> desde el mes pasado</span>
            </div>
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Mis finanzas</span>
              <div class="count green">XX,XX</div>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>6.3% </i> Mejora respecto al mes pasado</span>
            </div>
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Mis créditos</span>
              <div class="count">$823,426</div>
              <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>2.3% </i> Exposición de riesgo desde el mes pasado</span>
            </div>
          </div>
          <!-- /top tiles -->
